'''
Marc Coll 05/2021

Add support for passing command line arguments. In order to use this feature you
just need to add the following two lines to your script:
    from mudpy import parsecmdargs
    parsecmdargs.parse_cmdline_arguments(globals())
They must be placed right after all the global configuration variables (ncpus,
model_name, fault_name, NFFT...) have been declared.


Edited: Marcus Adair 06/2022

Added changes necessary for additional parameters used by MudPy functions in 2022

took out use_gpu stuff as that wasn't merged into current version of MudPy. 

'''

import argparse
import sys
import re
import numpy as np
from obspy.core import UTCDateTime


def parse_cmdline_arguments(gobal_vars):
    if (len(sys.argv) <= 1):
        return

    '''
    Add here the names of the variables you want to be able to modify from the command line,
    and then modify the parse function accordingly
    '''
    params = [
        # FUNCTIONS:
        # Old:
        'init',
        'make_ruptures',
        'make_GFs',
        'make_synthetics',
        'make_waveforms',
        'load_distances',
        'G_from_file',

        # New:
        'quasistatic2dynamic',
        'make_statics',

        # split gflist to sub files and run with g_cpu, choose runing above or using G-split
        'make_sub_G',    # split G matrices
        'sta_split',     # station split
        'g_cpu',         # ncpus
        'make_sub_waveforms',
        'make_hf_waveforms',
        'match_filter',

        # PARAMETERS:
        # Old:
        'ncpus',
        'model_name',
        'fault_name',
        'slab_name',
        'mesh_name',
        'distances_name',
        'UTM_zone',
        'scaling_law',
        #'dynamic_GFlist',
        #'dist_threshold',
        'Nrealizations',
        'max_slip',
        'hurst',
        'Ldip',
        'Lstrike',
        'lognormal',
        'slip_standard_deviation',
        'num_modes',
        'rake',
        'force_magnitude',
        'force_area',
        #'no_random',
        'time_epi',
        #'hypocenter',
        'force_hypocenter',
        #'mean_slip',
        #'center_subfault',
        'use_hypo_fraction',
        'source_time_function',
        'rise_time_depths',
        # 'shear_wave_fraction',
        'GF_list',
        'G_name',
        'NFFT',
        'dt',
        'dk',
        'pmin',
        'pmax',
        'kmax',
        'custom_stf',
        'rupture_list',
        'target_Mw',
        'max_slip_rule',
        #'slip_tol',
        # 'shear_wave_fraction_deep',
        # 'shear_wave_fraction_shallow',
        #'zeta',
        'stf_falloff_rate',
        #'rupture_name',
        #'epicenter',
        'hot_start',
        #'impulse',
        'home',
        'project_name',
        'run_name',

        # New
        'moho_depth_in_km',
        'hf_dt',
        'duration',
        'Pwave',
        'zero_phase',
        'order',
        'fcorner',
        'inpolygon_fault',
        'inpolygon_hypocenter',
        'high_stress_depth',
        'stress_parameter'
    ]
    
    dict_params = {}
    for p in params:
        #Get values from existing variables using their names
        dict_params[p] = gobal_vars[p]
    ok,actions=parse(dict_params)
    if (ok == False):
        exit(1)
    if (len(actions) > 0):
        print("Actions: {}\nConfiguration:".format(actions))
    max_length = max(len(p) for p in params)
    for p in params:
        padding = ''.ljust(max_length - len(p) + 1)
        print("\t{}{}= {}".format(p, padding, dict_params[p]))
        #Set values to existing variables using their names
        gobal_vars[p] = dict_params[p]
    print("\n")


def parse(params):
    prog = sys.argv[0]
    description = "MudPy's command line arguments"
    epilog = '''Examples:
    {} init
    {} make_ruptures -load_distances=T
    {} make_waveforms -ncpus=16 -nfft=128 -source_time_function=dreger
    {} make_ruptures make_g_files make_waveforms -load_distances=F -ncpus=16 -lognormal=T
    '''.format(prog, prog, prog, prog)

    bool_choices=['T', 'F', 't', 'f', '0', '1']
    ldip_lstrike_choices=['auto', 'MB2002', 'MH2019']

    # Parse command line parameters
    parser = argparse.ArgumentParser(description=description, epilog=epilog,
                                     formatter_class=argparse.RawTextHelpFormatter)

    # What do you want to do?
    parser.add_argument('actions', nargs='*',
                        
                        # TODO: Add SSE functions
                        metavar='[{init,make_ruptures,make_g_files,make_waveforms}]',
                        choices=['init', 'make_ruptures', 'make_g_files', 'make_waveforms'],
                        help='What do you want to do?\n'
                             ' * init: initialize project folders\n'
                             ' * make_ruptures: generate rupture models\n'
                             ' * make_g_files: prepare waveforms and synthetics\n'
                             ' * make_waveforms: synthesize the waveforms')

    parser.add_argument('-load_distances', default=str(params['load_distances']), metavar='[TF]',
                        choices=bool_choices,
                        help='load the distances instead of calculating them')
    parser.add_argument('-g_from_file', default=str(params['G_from_file']), metavar='[TF]',
                        choices=bool_choices,
                        help='read the LARGE matrix (must run make_waveforms first)')

    # Run-time parameters
    parser.add_argument('-ncpus', type=int, default=params['ncpus'], metavar='N',
                        help='number of CPUs to use')
    parser.add_argument('-model_name', default=params['model_name'], metavar='NAME',
                        help='velocity model')
    parser.add_argument('-fault_name', default=params['fault_name'], metavar='NAME',
                        help='fault geometry')
    parser.add_argument('-slab_name', default=params['slab_name'], metavar='NAME',
                        help='slab 1.0 Ascii file (only used for 3D fault)')
    parser.add_argument('-mesh_name', default=params['mesh_name'], metavar='NAME',
                        help='GMSH output file (only used for 3D fault)')
    parser.add_argument('-distances_name', default=params['distances_name'], metavar='NAME',
                        help='name of distance matrix')
    parser.add_argument('-utm_zone', default=params['UTM_zone'], metavar='ZONE',
                        help='as defined in the Universal Transverse Mercator coordinate system')
    parser.add_argument('-scaling_law', default=params['scaling_law'], metavar='[TSN]',
                        #choices=['T', 'S', 'N'],
                        help='T for thrust, S for strike-slip, N for normal')

    # Dynamic GFlist options
    # parser.add_argument('-dynamic_gflist', default=str(params['dynamic_GFlist']), metavar='[TF]',
    #                     choices=bool_choices,
    #                     help='use dynamic GFlist')
    # parser.add_argument('-dist_threshold', type=float, default=params['dist_threshold'], metavar='N',
    #                     help='(degree) station to the closest subfault must be closer to this distance')

    # Slip parameters
    parser.add_argument('-nrealizations', type=int, default=params['Nrealizations'], metavar='N',
                        help='fake ruptures to generate per magnitude bin. Let Nrealizations %% ncpus=0')
    parser.add_argument('-max_slip', type=float, default=params['max_slip'], metavar='N',
                        help='maximum slip (m) allowed in the model')

    # Correlation function parameters
    parser.add_argument('-hurst', type=float, default=params['hurst'], metavar='N',
                        help='0.4~0.7 is reasonable')
    parser.add_argument('-ldip', default=params['Ldip'],
                        choices=ldip_lstrike_choices,
                        help='Correlation length scaling')
    parser.add_argument('-lstrike', default=params['Lstrike'],
                        choices=ldip_lstrike_choices,
                        help='Lstrike value (correlation function parameter)')
    parser.add_argument('-lognormal', default=str(params['lognormal']), metavar='[TF]',
                        choices=bool_choices,
                        help='')
    parser.add_argument('-slip_standard_deviation', type=float, default=params['slip_standard_deviation'], metavar='N',
                        help='')
    parser.add_argument('-num_modes', type=int, default=params['num_modes'], metavar='N',
                        help='modes in K-L expantion (max#= number of subfaults)')
    parser.add_argument('-rake', type=float, default=params['rake'], metavar='N',
                        help='')

    # Rupture parameters
    parser.add_argument('-force_magnitude', default=str(params['force_magnitude']), metavar='[TF]',
                        choices=bool_choices,
                        help='make the magnitudes EXACTLY the value in target_Mw')
    parser.add_argument('-force_area', default=str(params['force_area']), metavar='[TF]',
                        choices=bool_choices,
                        help='forces using the entire fault area defined by the .fault file')
    # parser.add_argument('-no_random', default=str(params['no_random']), metavar='[TF]',
    #                     choices=bool_choices,
    #                     help='if true uses median length/width if false draws from prob. distribution')
    parser.add_argument('-time_epi', default=params['time_epi'].isoformat(), metavar='TIME',
                        help='defines the hypocentral time')
    


    # parser.add_argument('-hypocenter', default=','.join(str(s) for s in params['hypocenter']), metavar='N,N,N',
    #                     help='defines the specific hypocenter location if force_hypocenter=True')

    # For None    
    # parser.add_argument('-hypocenter', default=params['hypocenter'], metavar='N,N,N or None',
    #                     help='defines the specific hypocenter location if force_hypocenter=True')




    parser.add_argument('-force_hypocenter', default=str(params['force_hypocenter']), metavar='[TF]',
                        choices=bool_choices,
                        help='forces hypocenter to occur at specified location as opposed to random')
    # parser.add_argument('-mean_slip', default=params['mean_slip'], metavar='NAME',
    #                     help='provide path to file name of .rupt to be used as mean slip pattern')

    # parser.add_argument('-center_subfault', default=params['center_subfault'], metavar='N or None',
    #                     help='use this subfault as center for defining rupt area') 
    parser.add_argument('-use_hypo_fraction', default=str(params['use_hypo_fraction']), metavar='[TF]',
                        choices=bool_choices,
                        help='if true use hypocenter PDF positions from Melgar & Hayes 2019, if false then selects at random')

    # Kinematic parameters
    parser.add_argument('-source_time_function', default=params['source_time_function'],
                        choices=['triangle', 'cosine', 'dreger', 'ji'],
                        help='calculation method used in source time function')
    parser.add_argument('-rise_time_depths', default=','.join(str(s) for s in params['rise_time_depths']), metavar='N,N',
                        help='transition depths for rise time scaling')
    # parser.add_argument('-shear_wave_fraction', type=float, default=params['shear_wave_fraction'], metavar='N',
    #                     help='fraction of shear wave speed to use as mean rupture velocity')

    # Station information (only used when syntehsizing waveforms)
    parser.add_argument('-gf_list', default=params['GF_list'], metavar='NAME',
                        help='name of the GF list file')
    parser.add_argument('-g_name', default=params['G_name'], metavar='NAME',
                        help='name of the GF folder')

    # Displacement and velocity waveform parameters
    parser.add_argument('-nfft', type=int, default=params['NFFT'], metavar='N',
                        help='NFFT (displacement and velocity waveform parameter)')
    parser.add_argument('-dt', type=float, default=params['dt'], metavar='N',
                        help='dt (displacement and velocity waveform parameter)')

    # fk-parameters
    parser.add_argument('-dk', type=float, default=params['dk'], metavar='N',
                        help='dk (fk parameter)')
    parser.add_argument('-pmin', type=int, default=params['pmin'], metavar='N',
                        help='pmin (fk parameter)')
    parser.add_argument('-pmax', type=int, default=params['pmax'], metavar='N',
                        help='pmax (fk parameter)')
    parser.add_argument('-kmax', type=int, default=params['kmax'], metavar='N',
                        help='kmax (fk parameter)')
    parser.add_argument('-custom_stf', default=params['custom_stf'], metavar='STF',
                        help='custom_stf (fk parameter)')





    # Arguments added by Marcus Adair in 2022

    parser.add_argument('-rupture_list', default=params['rupture_list'], metavar='NAME',
                        help='Dont change this (unless you know waht you are doing!)')  
    parser.add_argument('-target_mw', default=','.join(str(s) for s in params['target_Mw']), metavar='N,N,N',
                        help='Parameters to be plugged into numpy.arange to specifiy of what approximate magnitudes')
    parser.add_argument('-max_slip_rule', default=str(params['max_slip_rule']), metavar='[TF]',
                        choices=bool_choices,
                        help='true or false')   
    # parser.add_argument('-slip_tol', type=float, default=params['slip_tol'], metavar='N',
    #                     help='Slip tolerance')
    # parser.add_argument('-shear_wave_fraction_deep', type=float, default=params['shear_wave_fraction_deep'], metavar='N',
    #                     help='Deep fraction of shear wave speed to use during calculation of rupture velocity')
    # parser.add_argument('-shear_wave_fraction_shallow', type=float, default=params['shear_wave_fraction_shallow'], metavar='N',
    #                     help='Shallow fraction of shear wave speed to use during calculation of rupture velocity')
    # parser.add_argument('-zeta', type=float, default=params['zeta'], metavar='N',
    #                     help='used in making waveforms')
    parser.add_argument('-stf_falloff_rate', type=float, default=params['stf_falloff_rate'], metavar='N',
                        help='STF falloff rate as a decimal point number ')
    # parser.add_argument('-rupture_name', default=params['rupture_name'], metavar='NAME',
    #                     help='Name of rupture description file')   
    # parser.add_argument('-epicenter', default=params['epicenter'], metavar='N,N,N or None',
    #                     help='Epicenter coordinates. Default is None')
    parser.add_argument('-hot_start', type=int, default=params['hot_start'], metavar='N',
                        help='=k if you want to start computations at k-th subfault, =0 to compute all')
    # parser.add_argument('-impulse', default=str(params['impulse']), metavar='[TF]',
    #                     choices=bool_choices,
    #                     help='true or false')

    #
    parser.add_argument('-home', default=params['home'], metavar='PATH',
                        help='The directory where the folder structure created by init lies')
    parser.add_argument('-project_name', default=params['project_name'], metavar='NAME',
                        help='The name of the directory created in the init step')       
    parser.add_argument('-run_name', default=params['run_name'], metavar='NAME',
                        help='Name of the run. Can be be changed for labeling data when recycling parameters')         
    

    # Add SSE Arguments:
    parser.add_argument('-moho_depth_in_km', type=float, default=params['moho_depth_in_km'], metavar='N')
    parser.add_argument('-hf_dt', type=float, default=params['hf_dt'], metavar='N')
    parser.add_argument('-fcorner', type=float, default=params['fcorner'], metavar='N')

    parser.add_argument('-duration', type=int, default=params['duration'], metavar='N')
    parser.add_argument('-order', type=int, default=params['order'], metavar='N')
    parser.add_argument('-high_stress_depth', type=int, default=params['high_stress_depth'], metavar='N')
    parser.add_argument('-stress_parameter', type=int, default=params['stress_parameter'], metavar='N')
    
    parser.add_argument('-pwave', default=str(params['Pwave']), metavar='[TF]',
                    choices=bool_choices,
                    help='')
    parser.add_argument('-zero_phase', default=str(params['zero_phase']), metavar='[TF]',
                choices=bool_choices,
                help='')
    
    parser.add_argument('-inpolygon_fault', default=params['inpolygon_fault'], metavar='NAME') 
    parser.add_argument('-inpolygon_hypocenter', default=params['inpolygon_hypocenter'], metavar='NAME')  



    # Default initialization of actions
    params['init'] = 0
    params['make_ruptures'] = 0
    params['make_GFs'] = 0
    params['make_synthetics'] = 0
    params['make_waveforms'] = 0

    # Default init of SSE actions
    params['quasistatic2dynamic'] = 0
    params['make_statics'] = 0
    params['make_sub_G'] = 0
    params['sta_split'] = 0
    params['g_cpu'] = 0
    params['make_sub_waveforms'] = 0


    

    # Get parameter values
    args = parser.parse_args()
    if ('init' in args.actions):
        params['init'] = 1
    if ('make_ruptures' in args.actions):
        params['make_ruptures'] = 1
        #params['load_distances'] = get_intbool(args.load_distances)
    if ('make_g_files' in args.actions):
        params['make_GFs'] = 1
        params['make_synthetics'] = 1
    if ('make_waveforms' in args.actions):
        params['make_waveforms'] = 1
        #params['G_from_file'] = get_intbool(args.g_from_file)


    # TODO: MAKE SURE CORRECT!!
    # --- SSE ------------------ #
    # For splitting G matrices
    if ('quasistatic2dynamic' in args.actions):
        params['quasistatic2dynamic'] = 1
    if ('make_statics' in args.actions):
        params['make_statics'] = 1

    if ('make_sub_G' in args.actions):
        params['make_sub_G'] = 1
        params['sta_split'] = args.sta_split
        params['g_cpu'] = args.g_cpu
        params['make_sub_waveforms'] = 1

    if ('make_hf_waveforms' in args.actions):
        params['make_hf_waveforms'] = 1
    if ('match_filter' in args.actions):
        params['match_filter'] = 1
    # --- SSE ------------------ #
        
    

    params['load_distances'] = get_intbool(args.load_distances)
    params['G_from_file'] = get_intbool(args.g_from_file)

    # Simulation Configurations:
    # ------------------------------ #
    params['ncpus'] = args.ncpus
    params['model_name'] = args.model_name
    params['fault_name'] = args.fault_name
    params['slab_name'] = args.slab_name
    params['mesh_name'] = args.mesh_name
    params['distances_name'] = args.distances_name
    params['UTM_zone'] = args.utm_zone
    params['scaling_law'] = args.scaling_law
    # params['dynamic_GFlist'] = get_bool(args.dynamic_gflist)
    # params['dist_threshold'] = args.dist_threshold
    params['Nrealizations'] = args.nrealizations
    params['max_slip'] = args.max_slip
    params['hurst'] = args.hurst
    params['Ldip'] = args.ldip
    params['Lstrike'] = args.lstrike
    params['lognormal'] = get_bool(args.lognormal)
    params['slip_standard_deviation'] = args.slip_standard_deviation
    params['num_modes'] = args.num_modes
    params['rake'] = args.rake
    params['force_magnitude'] = get_bool(args.force_magnitude)
    params['force_area'] = get_bool(args.force_area)
    # params['no_random'] = get_bool(args.no_random)
    params['time_epi'] = UTCDateTime(args.time_epi)
    # params['hypocenter'] = get_listOrNone(args.hypocenter, float)
    params['force_hypocenter'] = get_bool(args.force_hypocenter)
    #params['mean_slip'] = args.mean_slip
    params['center_subfault'] = args.center_subfault
    params['use_hypo_fraction'] = get_bool(args.use_hypo_fraction)
    params['source_time_function'] = args.source_time_function
    params['rise_time_depths'] = get_list(args.rise_time_depths, int)
    # params['shear_wave_fraction'] = args.shear_wave_fraction
    params['GF_list'] = args.gf_list
    params['G_name'] = args.g_name
    params['NFFT'] = args.nfft
    params['dt'] = args.dt
    params['dk'] = args.dk
    params['pmin'] = args.pmin
    params['pmax'] = args.pmax
    params['kmax'] = args.kmax
    params['custom_stf'] = args.custom_stf

 

    # Paramaters added by Marcus Adair in 2022
    params['rupture_list'] = args.rupture_list
    params['target_Mw'] = get_list_call_arange(args.target_mw, float)
    params['max_slip_rule'] = get_bool(args.max_slip_rule)
    params['slip_tol'] = args.slip_tol  
    params['stf_falloff_rate'] = args.stf_falloff_rate
    params['hot_start'] = args.hot_start
    params['home'] = args.home
    params['project_name'] = args.project_name
    params['run_name'] = args.run_name

    #  SSE params ------------- Added by Marcus Adair Dec. 2023
    params['moho_depth_in_km'] = args.moho_depth_in_km
    params['hf_dt'] = args.hf_dt
    params['fcorner'] = args.fcorner

    params['duration'] = args.duration
    params['order'] = args.order
    params['high_stress_depth'] = args.high_stress_depth
    params['stress_parameter'] = args.stress_parameter

    params['stress_parameter'] = get_bool(args.stress_parameter)
    params['zero_phase'] = get_bool(args.zero_phase)

    params['inpolygon_fault'] = args.inpolygon_fault
    params['inpolygon_hypocenter'] = args.inpolygon_hypocenter




    # Not in SSE:
    # params['shear_wave_fraction_deep'] = args.shear_wave_fraction_deep
    # params['shear_wave_fraction_shallow'] = args.shear_wave_fraction_shallow
    # params['zeta'] = args.zeta
    # params['rupture_name'] = args.rupture_name
    # params['epicenter'] = get_listOrNone(args.epicenter)
    # params['impulse'] = get_bool(args.impulse)





    # Check if some of the parameters make sense
    if (args.ncpus < 1):
        print('Invalid number of CPUs')
        return False,None

    regex_timeepi = re.compile('^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(.[0-9]+Z?)?$')
    if (not regex_timeepi.match(args.time_epi)):
        print('Invalid hypocentral time')
        return False,None

    # if (len(params['hypocenter']) != 3):
    #     print('Invalid number of hypocenter coordinates')
    #     return False,None

    if (len(params['rise_time_depths']) != 2):
        print('Invalid number of rise time depths')
        return False,None

    regex_utmzone = re.compile('^(A|B|Y|Z|([1-5][0-9]|60|0[1-9])[C-X])$')
    if (not regex_utmzone.match(args.utm_zone)):
        print('Invalid UTM zone')
        return False,None

    return True,args.actions



# Helper Methods:
# ------------------------- #
def get_list(value, dtype):
    return list(map(dtype, list(value.split(','))))

def get_listOrNone(value):
    if (value == 'None' or value is None):
        return value
    else:
        return list(map(float, list(value.split(','))))

def get_bool(value):
    v = value.upper()
    return (v == 'T' or value == '1')


def get_intbool(value):
    if get_bool(value):
        return 1
    else:
        return 0

def get_list_call_arange(value, dtype):
    param_list = get_list(value, dtype) # seperate the values into a list

    param0 = param_list[0]
    param1 = param_list[1]
    param2 = param_list[2]

    return np.arange(param0, param1, param2)
        

