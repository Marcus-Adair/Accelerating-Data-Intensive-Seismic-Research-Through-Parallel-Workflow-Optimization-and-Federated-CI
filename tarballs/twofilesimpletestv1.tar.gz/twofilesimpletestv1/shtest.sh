PROJNAME=$1

# get the last character off the project_name which is the runnumber
# PROJNAME is in format: fakequakes_run$(runnumber)
runnum="${PROJNAME##*fakequakes_run}"


python3 testPy.py $runnum

