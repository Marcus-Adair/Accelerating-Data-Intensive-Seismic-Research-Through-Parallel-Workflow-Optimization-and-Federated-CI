import sys

param1=sys.argv[1]

print('hello singularity world')

toprint='the runnumber is: ' + param1
print(toprint)

