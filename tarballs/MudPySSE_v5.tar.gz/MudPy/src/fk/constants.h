c***************************************************************
c  F-K: @(#) constants.h		1.0 4/29/2000
c
c  Copyright (c) 2000 by L. Zhu
c  See README file for copying and redistribution conditions.
c***************************************************************

c
c some constants
	real pi, pi2
	parameter(pi=3.1415926536,pi2=6.2831853072)
	real*8 zero,one,two,three,four
	parameter(zero=0.d0,one=1.d0,two=2.d0,three=3.d0,four=4.d0)
