#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 13 11:33:25 2023

@author: sheng

---
Modified by: Marcus Adair Dec 15 2023
"""

from mudpy import fakequakes,runslip,forward,viewFQ
import numpy as np
from obspy.core import UTCDateTime
import time
import sys



########                            GLOBALS                             ########
# SOME OF THE FOLLOWING PARAMETERS WILL BE CHANGED/CORRECTED by parsecmdargs with arguments from a config file

home = '/PATH/TO/projects'		# get the absolute path of the current working directory which was passed in as as argument. set home

# Get the name of the job passed in. All the output data will be contained in a dir named after this unique job 
project_name = 'Chile_example_CHANGE_THIS_W_-project_name'

#  home+project_name = path to the output dir
run_name = 'run_v1'
################################################################################


##############             What do you want to do??           ##################
init=0
make_ruptures=0
make_GFs=0
make_synthetics=0
make_waveforms=0

# New stuff -------------------- #
quasistatic2dynamic=0
make_statics=0

# split gflist to sub files and run with g_cpu, choose runing above or using G-split
make_sub_G=0    # split G matrices
sta_split=5     # station split
g_cpu=4         # ncpus
make_sub_waveforms=0 # run with sub G

make_hf_waveforms=0
match_filter=0
# ------------------------------ #


# Things that only need to be done once
load_distances=1
G_from_file=0
###############################################################################


#############                 Run-time parameters            ##################
ncpus=4
hot_start=0
model_name='cascadia.mod'   # Velocity model
#velmod_file=home+project_name+'/structure/iquique'
moho_depth_in_km=25.0
#fault_name='iquique_gfz.fault'    # Fault geometry
fault_name='csz_coarse.fault'
slab_name='cas_slab2_dep_02.24.18.xyz'    # Slab 1.0 Ascii file
mesh_name=None
#slab_name=None# Slab 1.0 Ascii file
#mesh_name=None
distances_name='csz_coarse' # Name of dist matrix
rupture_list='ruptures.list'
#rupture_list='testruptures.list'
UTM_zone='10'
scaling_law='SSE' # T for thrust, S for strike-slip, N for normal, SSE for slow slip

#Station information
GF_list='sta30.gflist'
G_name='gnss'
G_name_static='gnss'

Nrealizations=12 # Number of fake ruptures to generate per magnitude bin
target_Mw=np.linspace(5,6,2) #np.array([5,7]) # Of what approximate magnitudes
max_slip=0.5 #Maximum sip (m) allowed in the model

# MARCUS NOTE: THIS IS 'T' IN .FQ.PY
max_slip_rule=True #restrict max slip to 3 times Allen & Hayes 2017

# Displacement and velocity waveform parameters
NFFT=60 ; dt=3600*4 #1.0 NFFT: sampling rate, and total period: NFFT*dt
#fk-parameters
dk=0.1 ; pmin=0 ; pmax=1 ; kmax=20
custom_stf=None

#High frequency waveofmr parameters
hf_dt=0.01
duration=120
Pwave=True

#Match filter parameters
zero_phase=False
order=4
fcorner=1.0

# Correlation function parameters
hurst=0.75 # Melgar and Hayes 2019 found Hurst exponent is probably closer to 0.4?
Ldip='auto' # Correlation length scaling, 'MB2002' Mai & Beroza 2002
Lstrike='auto' # 'auto' uses MH2019 uses Melgar & Hayes 2019
lognormal=True # Keep this as true
slip_standard_deviation=0.46 # Value from Melgar & Hayes 2019

# Rupture parameters
time_epi=UTCDateTime('2014-04-01T23:46:47Z')
hypocenter=None #closest subfault in the finer .rupt to USGS hypo (lowest t_rupt in model)
source_time_function='ji' # options are 'triangle' or 'cosine' or 'dreger'
stf_falloff_rate=4 #Only affects Dreger STF, choose 4-8 are reasonaclosble values
num_modes=200 # The more modes, the better you can model the high frequency stuff
stress_parameter=50 #measured in bars
high_stress_depth=30 # SMGA must be below this depth (measured in km)
rake=90 # average rake
rise_time_depths=[1,2]#[10,15] #Transition depths for rise time scaling (if slip shallower than first index, rise times are twice as long as calculated)
buffer_factor=0.5 # I don't think this does anything anymore-- remove?
mean_slip_name=None #'/Users/yu-shengsun/Documents/Diego/Fakequake/cas_coarse/data/model_info/mean_slip.rupt'
#shear_wave_fraction=1/60/60/24 # rupture speed: it times the velocity of structure, default 0.8
rise_time='SSE_self_similar' #'GP2010', 'GP2015', 'S1999', 'MH2017', 'SSE','SSE_self_similar'(Gao2012)


force_area=False
shypo=None
inpolygon_hypocenter='/Users/sheng/Documents/Projects/Fakequake/osg_test1/data/model_info/hypo_4548' # constrain the hypo location
# constrain the fault area from the original, but the rupture file will be written with the original 
inpolygon_fault='/Users/sheng/Documents/Projects/Fakequake/osg_test1/data/model_info/hypo_4548' 
force_magnitude=False
force_hypocenter=False
use_hypo_fraction=False
###############################################################################


# custom command line stuff
from mudpy import parsecmdargs_SSE
parsecmdargs_SSE.parse_cmdline_arguments(globals())     # change above default variables to what is passeed in via command line (if they are passed)
home = home+'/'    



#Initalize project folders
if init==1:
    fakequakes.init(home,project_name)


#Generate rupture models
if make_ruptures==1: 
    fakequakes.generate_ruptures(home,project_name,run_name,fault_name,slab_name,
            mesh_name,load_distances,distances_name,UTM_zone,target_Mw,model_name,
            hurst,Ldip,Lstrike,num_modes,int(Nrealizations),rake,rise_time,
            rise_time_depths,time_epi,max_slip,source_time_function,lognormal,
            slip_standard_deviation,scaling_law,ncpus,mean_slip_name=mean_slip_name,
            force_magnitude=force_magnitude,force_area=force_area,hypocenter=hypocenter,
            force_hypocenter=force_hypocenter,shypo=shypo,
            max_slip_rule=max_slip_rule,use_hypo_fraction=use_hypo_fraction,
            inpolygon_hypocenter=inpolygon_hypocenter,inpolygon_fault=inpolygon_fault)

# Prepare waveforms and synthetics       
if make_GFs==1 or make_synthetics==1 or quasistatic2dynamic==1:
    runslip.inversionGFs(home,project_name,GF_list,None,fault_name,model_name,
        dt,None,NFFT,None,make_GFs,make_synthetics,dk,pmin,
        pmax,kmax,0,time_epi,hot_start,ncpus,custom_stf,impulse=True,
        quasistatic2dynamic=quasistatic2dynamic) 

#Make low frequency waveforms
if make_waveforms==1:
    forward.waveforms_fakequakes(home,project_name,fault_name,rupture_list,GF_list,
                model_name,run_name,dt,NFFT,G_from_file,G_name,source_time_function,
                stf_falloff_rate,hot_start=hot_start,ncpus=ncpus)

if make_statics==1:
    forward.coseismics_fakequakes(home,project_name,GF_list,G_from_file,G_name_static,
                          model_name,rupture_list)
if make_sub_G==1: 
    forward.load_fakequakes_synthetics_sub(home,project_name,fault_name,model_name,GF_list,
                                                   G_from_file,G_name,sta_split,g_cpu)
if make_sub_waveforms==1:
    G_from_file=1
    forward.waveforms_fakequakes_sub(home,project_name,fault_name,rupture_list,GF_list,
            model_name,run_name,dt,NFFT,G_from_file,G_name,source_time_function,
            stf_falloff_rate,sta_split,hot_start,ncpus)
#Make semistochastic HF waveforms         
#if make_hf_waveforms==1:
#    forward.run_hf_waveforms(home,project_name,fault_name,rupture_list,GF_list,
#                model_name,run_name,dt,NFFT,G_from_file,G_name,rise_time_depths,
#                moho_depth_in_km,source_time_function=source_time_function,
#                duration=duration,stf_falloff_rate=stf_falloff_rate,hf_dt=hf_dt,
#                Pwave=Pwave,hot_start=hot_start,stress_parameter=stress_parameter,
#                high_stress_depth=high_stress_depth)
if make_hf_waveforms==1:
    forward.hf_waveforms(home,project_name,fault_name,rupture_list,GF_list,
                model_name,run_name,dt,NFFT,G_from_file,G_name,rise_time_depths,
                moho_depth_in_km,ncpus,source_time_function=source_time_function,
                duration=duration,stf_falloff_rate=stf_falloff_rate,hf_dt=hf_dt,
                Pwave=Pwave,hot_start=hot_start,stress_parameter=stress_parameter,
                high_stress_depth=high_stress_depth)

# Combine LF and HF waveforms with match filter                              
if match_filter==1:
    forward.match_filter(home,project_name,fault_name,rupture_list,GF_list,
            zero_phase,order,fcorner)





