'''
Marcus Adair June 2022

    This initializes the project folder structure for fakequake simulations. The top-level directory is uniquely named according to 
the number of the $(Cluster) and $(Process) passed in via a wrapper file and determined by OSG. That wrapper file also passes
in the path of the workng directory so that the folder structure can be made.

'''

from mudpy import fakequakes,runslip,forward
import numpy as np
from obspy.core import UTCDateTime
import sys


########                            GLOBALS                             ########


dirPath = sys.argv[1]		# get the absolute path of the current working directory which was passed in as as argument
home = str(dirPath)+'/'		# set the home


# Get the name of the job passed in. All the output data will be  contained in a dir named after this unique job 
project_name = str(sys.argv[2]) 

# home + project_name  -- this is the directory for MudPy to write output data to
 

#home='/Users/marcusadair/Work_ResearchAsst/projects/' 
#project_name='chile_example'  
###################

###############################################################################

#Initalize project folders
fakequakes.init(home,project_name) 
