'''
Fakequakes runs with a simple planar geometry
'''


from mudpy import fakequakes,runslip,forward
import numpy as np
from obspy.core import UTCDateTime


########                            GLOBALS                             ########
home='/Users/marcusadair/Work_ResearchAsst/projects/' #'/Users/timlin/TESTMudpy/'
project_name='Chile_example_runSim_test'
run_name='chile_ex_rst_v1'
################################################################################


##############             What do you want to do??           ##################
init=0
make_ruptures=0      
make_GFs=0           #make GF file from fk (.grn[0~9])
make_synthetics=0    #make sta.SS.[enu], sta.DS.[enu] component for all subfaults
make_waveforms=1     #sum all subfault data
# Things that only need to be done once
load_distances=1
G_from_file=0  #read the G matrix? (NSS,ESS,ZSS,NDS,EDS and ZDS from "must run make_waveforms=1 first")
###############################################################################


#############                 Run-time parameters            ##################

ncpus=4 # set to 1 when first running make_ruptures=1

model_name='Vel1D_Chile.mod'   # Velocity model
fault_name='chile.fault'    # Fault geometry
slab_name='chile.xyz'   # Slab 1.0 Ascii file (only used for 3D fault)
mesh_name='chile.mshout'    # GMSH output file (only used for 3D fault)
distances_name='planar_subduction' # Name of distance matrix
rupture_list='ruptures.list'  # Don't change this (unless you know waht you're doing!)
UTM_zone='19J'  #Look here if unsure (https://en.wikipedia.org/wiki/Universal_Transverse_Mercator_coordinate_system#/media/File:Utm-zones.jpg)
scaling_law='T' # T for thrust, S for strike-slip, N for normal

#####################################################
'''
    Dynamic GFlist option
    Run make_GFs=1, make_synthetics=1 first. Make sure you already generate all Nss,Ess,Zss.....:
     To check: Go to matrix dir, load the mseed and check the length. THe len should be n_subfaults * n_stations
    
'''
dynamic_GFlist=True #dynamic GFlist? (True/False)
dist_threshold=50.0 #(degree) station to the closest subfault must be closer to this distance
#GF_list_sub=None # A smaller GF_list that you want to generate synthetic data

#####################################################

#slip parameters
Nrealizations=4 # Number of fake ruptures to generate per magnitude bin. let Nrealizations % ncpus=0
target_Mw=np.arange(8.5,9.2,0.2) # Of what approximate magnitudes
max_slip=100 #Maximum slip (m) allowed in the model

# Correlation function parameters
hurst=0.4  #0.4~0.7 is reasonable
Ldip='auto' # 'MH2019'      # Correlation length scaling, 'auto' uses  Mai & Beroza 2002, 
Lstrike='auto' # 'MH2019'   # MH2019 uses Melgar & Hayes 2019
lognormal=True
slip_standard_deviation=0.9
num_modes=100   #modes in K-L expantion (max#= munber of subfaults )
rake=90.0

# Rupture parameters
#force_magnitude=True    #Make the magnitudes EXACTLY the value in target_Mw
force_magnitude=False    #Make the magnitudes EXACTLY the value in target_Mw
force_area=False   #Forces using the entire fault area defined by the .fault file as opposed to the scaling laws
no_random=False   #If true uses median length/width if false draws from prob. distribution
time_epi=UTCDateTime('2016-09-07T14:42:26')  #Defines the hypocentral time
hypocenter=[0.8301,0.01,27.67]    #Defines the specific hypocenter location if force_hypocenter=True
force_hypocenter=False     # Forces hypocenter to occur at specified lcoationa s opposed to random
mean_slip = None     #Provide path to file name of .rupt to be used as mean slip pattern
center_subfault = None   #Integer value, if != None use that subfault as center for defining rupt area. If none then slected at random
use_hypo_fraction = False  #If true use hypocenter PDF positions from Melgar & Hayes 2019, if false then selects at random

max_slip_rule=True # not sure what does (marcus adair), added to be up to date 
slip_tol=1e-2

# Kinematic parameters
source_time_function='dreger' # options are 'triangle' or 'cosine' or 'dreger'
rise_time_depths=[10,15] #Transition depths for rise time scaling
buffer_factor=0.5   # idon't think this does anything anymore, remove?
shear_wave_fraction = 0.8  #Fraction of shear wave speed to use as mean rupture velocity
shear_wave_fraction_deep=0.8 # value of 0.8 from git def of generate_ruptures
shear_wave_fraction_shallow=0.49 # value of 0.49 from git def of generate_ruptures

#Station information (only used when syntehsizing waveforms)
#GF_list='Chile_GNSS.gflist'
GF_list='Chile_GNSS_small.gflist'  #a copy of Chile_GNSS.gflist but only 5 stations
G_name='GFs'

# Displacement and velocity waveform parameters
NFFT=128 ; dt=1.0
# ones i added from the waveforms_fakequakes_dynGF def
stf_falloff_rate=4.0
rupture_name=None
epicenter=None
time_epi=None
hot_start=0

#fk-parameters
dk=0.1 ; pmin=0 ; pmax=1 ; kmax=20
custom_stf=None

###############################################################################


"""

|*** - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ***|
     This commented out section is original code but edited the way I got it working for Chile.fq.py
|*** - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ***|
    


#Initalize project folders
if init==1:
    fakequakes.init(home,project_name)
    
#Generate rupture models
#if make_ruptures==1:
#    fakequakes.generate_ruptures(home,project_name,run_name,fault_name,slab_name,
#       mesh_name,load_distances,distances_name,UTM_zone,target_Mw,model_name,hurst,Ldip,
#		Lstrike,num_modes,Nrealizations,rake,buffer_factor,rise_time_depths,time_epi,
#		max_slip,source_time_function,lognormal,slip_standard_deviation,scaling_law,ncpus,
#		force_magnitude=force_magnitude,force_area=force_area,mean_slip_name=mean_slip,
#       hypocenter=hypocenter,force_hypocenter=force_hypocenter,no_random=no_random,
#       shypo=center_subfault,use_hypo_fraction=use_hypo_fraction,shear_wave_fraction=shear_wave_fraction)
    
    
# updated to correct paramaters from Github as of May 20 2022    
#Generate rupture models
if make_ruptures==1:
    fakequakes.generate_ruptures(home,project_name,run_name,fault_name,slab_name,mesh_name,
		load_distances,distances_name,UTM_zone,target_Mw,model_name,hurst,Ldip,
		Lstrike,num_modes,Nrealizations,rake,rise_time_depths,time_epi,
		max_slip,source_time_function,lognormal,slip_standard_deviation,scaling_law,ncpus,
		force_magnitude,force_area,mean_slip,hypocenter,
		slip_tol,force_hypocenter,no_random,center_subfault,use_hypo_fraction,
		shear_wave_fraction_shallow,shear_wave_fraction_deep,max_slip_rule)
    
    
                
# Prepare waveforms and synthetics       
if make_GFs==1 or make_synthetics==1:
    runslip.inversionGFs(home,project_name,GF_list,None,fault_name,model_name,
        dt,None,NFFT,None,make_GFs,make_synthetics,dk,pmin,
        pmax,kmax,0,time_epi,0,ncpus,custom_stf,impulse=True)
    
    
#Compute GFs for the ivenrse problem  - ***this this the definition for runslip.inversionGFs for reference
#def inversionGFs(home,project_name,GF_list,tgf_file,fault_name,model_name,
#        dt,tsun_dt,NFFT,tsunNFFT,green_flag,synth_flag,dk,pmin,
#        pmax,kmax,beta,time_epi,hot_start,ncpus,custom_stf,impulse=False):
       
# Synthesize the waveforms
if make_waveforms==1:
    forward.waveforms_fakequakes(home,project_name,fault_name,rupture_list,GF_list,
                model_name,run_name,dt,NFFT,G_from_file,G_name,source_time_function)
    #forward.waveforms_fakequakes_dynGF(home,project_name,fault_name,rupture_list,GF_list,dynamic_GFlist,dist_threshold,
                #model_name,run_name,dt,NFFT,G_from_file,G_name,source_time_function,
                #stf_falloff_rate, rupture_name, epicenter, time_epi, 
                #hot_start,1)
    
# above called method definition for reference
#def waveforms_fakequakes_dynGF(home,project_name,fault_name,rupture_list,GF_list,dynamic_GFlist,dist_threshold,
                        # model_name,run_name,dt,NFFT,G_from_file,G_name,source_time_function='dreger',
                         #stf_falloff_rate=4.0,rupture_name=None,epicenter=None,time_epi=None,
                         #hot_start=0,ncpus=1):

"""

#
#    Runs a fakequakes simulation in one run of the code, rather than having to edit the file and run 4 times.
#
def runSim()
    
    # 1)
    #Initalize project folders   
    fakequakes.init(home,project_name)


    # 2)
    # ncpus =  1 when generating earthquakes, only need to be done once 
    ncpusCopy = ncpus
    ncpus = 1
            
    #Generate rupture models
    fakequakes.generate_ruptures(home,project_name,run_name,fault_name,slab_name,mesh_name,
        load_distances,distances_name,UTM_zone,target_Mw,model_name,hurst,Ldip,
        Lstrike,num_modes,Nrealizations,rake,rise_time_depths,time_epi,
        max_slip,source_time_function,lognormal,slip_standard_deviation,scaling_law,ncpus,
        force_magnitude,force_area,mean_slip,hypocenter,
        slip_tol,force_hypocenter,no_random,center_subfault,use_hypo_fraction,
        shear_wave_fraction_shallow,shear_wave_fraction_deep,max_slip_rule)

    # 3)
    ncpus = ncpusCopy # set back to number of CPUs, ncpus > 1
                       
    # Prepare waveforms and synthetics       
    runslip.inversionGFs(home,project_name,GF_list,None,fault_name,model_name,
        dt,None,NFFT,None,make_GFs,make_synthetics,dk,pmin,
        pmax,kmax,0,time_epi,0,ncpus,custom_stf,impulse=True)
    
        
    # 4)
    # Synthesize the waveforms
    forward.waveforms_fakequakes(home,project_name,fault_name,rupture_list,GF_list,
                model_name,run_name,dt,NFFT,G_from_file,G_name,source_time_function)



# Program starts here

runSim()  #  run the simulation
        



