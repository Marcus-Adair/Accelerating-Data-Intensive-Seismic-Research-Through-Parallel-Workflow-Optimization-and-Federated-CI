'''
Fakequakes runs with a simple planar geometry
'''


from mudpy import fakequakes,runslip,forward
import numpy as np
from obspy.core import UTCDateTime
import sys


########                            GLOBALS                             ########


dirPath = sys.argv[1]		# get the absolute path of the current working directory which was passed in as as argument
home = str(dirPath)+'/'		# set the home

# Get the name of the job passed in. All the output data will be  contained in a dir named after this unique job 
project_name = str(sys.argv[2]) 

run_name= project_name+'_run_1'

#home='/Users/marcusadair/Work_ResearchAsst/projects/' 
#project_name='chile_example' # home + project_name  -- this is the directory for output data,  
#run_name='chile_ex_osg_v1'
################################################################################


##############             What do you want to do??           ##################
init=0
make_ruptures=0      
make_GFs=0           #make GF file from fk (.grn[0~9])
make_synthetics=0    #make sta.SS.[enu], sta.DS.[enu] component for all subfaults
make_waveforms=1     #sum all subfault data
# Things that only need to be done once
load_distances=1
G_from_file=1  #read the G matrix? (NSS,ESS,ZSS,NDS,EDS and ZDS from "must run make_waveforms=1 first")
###############################################################################


#############                 Run-time parameters            ##################

ncpus=4 # set to 1 when first running make_ruptures=1

model_name='vel1d_chile.mod'   # Velocity model
fault_name='chile.fault'    # Fault geometry
slab_name='chile.xyz'   # Slab 1.0 Ascii file (only used for 3D fault)
mesh_name='chile.mshout'    # GMSH output file (only used for 3D fault)
distances_name='planar_subduction' # Name of distance matrix
rupture_list='ruptures.list'  # Don't change this (unless you know waht you're doing!)
UTM_zone='19J'  #Look here if unsure (https://en.wikipedia.org/wiki/Universal_Transverse_Mercator_coordinate_system#/media/File:Utm-zones.jpg)
scaling_law='T' # T for thrust, S for strike-slip, N for normal

#####################################################
'''
    Dynamic GFlist option
    Run make_GFs=1, make_synthetics=1 first. Make sure you already generate all Nss,Ess,Zss.....:
     To check: Go to matrix dir, load the mseed and check the length. THe len should be n_subfaults * n_stations
    
'''
dynamic_GFlist=True #dynamic GFlist? (True/False)
dist_threshold=50.0 #(degree) station to the closest subfault must be closer to this distance
#GF_list_sub=None # A smaller GF_list that you want to generate synthetic data

#####################################################

#slip parameters
Nrealizations=4 # Number of fake ruptures to generate per magnitude bin. let Nrealizations % ncpus=0
target_Mw=np.arange(8.5,9.2,0.2) # Of what approximate magnitudes
max_slip=100 #Maximum slip (m) allowed in the model

# Correlation function parameters
hurst=0.4  #0.4~0.7 is reasonable
Ldip='auto' # 'MH2019'      # Correlation length scaling, 'auto' uses  Mai & Beroza 2002, 
Lstrike='auto' # 'MH2019'   # MH2019 uses Melgar & Hayes 2019
lognormal=True
slip_standard_deviation=0.9
num_modes=100   #modes in K-L expantion (max#= munber of subfaults )
rake=90.0

# Rupture parameters
#force_magnitude=True    #Make the magnitudes EXACTLY the value in target_Mw
force_magnitude=False    #Make the magnitudes EXACTLY the value in target_Mw
force_area=False   #Forces using the entire fault area defined by the .fault file as opposed to the scaling laws
no_random=False   #If true uses median length/width if false draws from prob. distribution
time_epi=UTCDateTime('2016-09-07T14:42:26')  #Defines the hypocentral time
hypocenter=[0.8301,0.01,27.67]    #Defines the specific hypocenter location if force_hypocenter=True
force_hypocenter=False     # Forces hypocenter to occur at specified lcoationa s opposed to random
mean_slip = None     #Provide path to file name of .rupt to be used as mean slip pattern
center_subfault = None   #Integer value, if != None use that subfault as center for defining rupt area. If none then slected at random
use_hypo_fraction = False  #If true use hypocenter PDF positions from Melgar & Hayes 2019, if false then selects at random

max_slip_rule=True # not sure what does (marcus adair), added to be up to date 
slip_tol=1e-2

# Kinematic parameters
source_time_function='dreger' # options are 'triangle' or 'cosine' or 'dreger'
rise_time_depths=[10,15] #Transition depths for rise time scaling
buffer_factor=0.5   # idon't think this does anything anymore, remove?
shear_wave_fraction = 0.8  #Fraction of shear wave speed to use as mean rupture velocity
shear_wave_fraction_deep=0.8 # value of 0.8 from git def of generate_ruptures
shear_wave_fraction_shallow=0.49 # value of 0.49 from git def of generate_ruptures

#Station information (only used when syntehsizing waveforms)
#GF_list='Chile_GNSS.gflist'
GF_list='chile_gnss_small.gflist'  #a copy of Chile_GNSS.gflist but only 5 stations
G_name='GFs'

# Displacement and velocity waveform parameters
NFFT=128 ; dt=1.0
# ones i added from the waveforms_fakequakes_dynGF def
zeta=0.2
stf_falloff_rate=4.0
rupture_name=None
epicenter=None
hot_start=0
impulse=False

#fk-parameters
dk=0.1 ; pmin=0 ; pmax=1 ; kmax=20
custom_stf=None

###############################################################################


# Synthesize the waveforms
forward.waveforms_fakequakes(home,project_name,fault_name,rupture_list,GF_list,
            model_name,run_name,dt,NFFT,G_from_file,G_name,source_time_function,zeta,
            stf_falloff_rate,rupture_name,epicenter,time_epi,hot_start,1)
#forward.waveforms_fakequakes_dynGF(home,project_name,fault_name,rupture_list,GF_list,dynamic_GFlist,dist_threshold,
            #model_name,run_name,dt,NFFT,G_from_file,G_name,source_time_function,
            #stf_falloff_rate, rupture_name, epicenter, time_epi, hot_start,1)
